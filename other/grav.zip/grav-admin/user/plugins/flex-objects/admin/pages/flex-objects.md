---
title: Flex Objects

access:
    admin.flex-objects: true
    admin.super: true
---